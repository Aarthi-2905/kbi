// Get token from localStorage
const getToken = () => localStorage.getItem('token');

// To get all the notification for specific user or Admin
export async function allNotification(){
    const token = getToken();
    const response = await fetch(`${import.meta.env.VITE_HOST}:${import.meta.env.VITE_PORT}/notifications`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
                Authorization: "Bearer " + token,
        },
    });
    if (!response.ok) {
        throw new Error('Text submission failed');
    }
    const data = await response.json();
    return data;
}

//To delete the particular notification from all notification details
export async function readOneNotification(notificationToRemove){
    const token = getToken();
    const response = await fetch(`${import.meta.env.VITE_HOST}:${import.meta.env.VITE_PORT}/notifications/read_one`, {
        method : "PUT",
        headers: {
            'Content-Type': 'application/json',
            Authorization: "Bearer " + token,
        },
        body : JSON.stringify({"file_name" : notificationToRemove.split(" from ")[0], "email" : notificationToRemove.split(" from ")[1]})
    });
    if (!response.ok) {
        throw new Error('Text submission failed');
    }
    const data = await response.json();
    return data;
}

//To clear all the notification for particular user
export async function clearAllNotification(){
    const token = getToken();
    const response = await fetch(`${import.meta.env.VITE_HOST}:${import.meta.env.VITE_PORT}/notifications/read_all`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            Authorization: "Bearer " + token,
        },
        body: JSON.stringify({}) 
    });
    if (!response.ok) {
        throw new Error('Failed to clear notifications');
    }
    const data = await response.json();
    return data;
}