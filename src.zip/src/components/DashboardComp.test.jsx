import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import DashboardComp from './DashboardComp';
import * as Auth from '../utils/Auth';
import * as DashboardFetch from '../fetch/DashboardComp';

// Mock the modules
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

jest.mock('../utils/Auth');
jest.mock('../fetch/DashboardComp');
jest.mock('react-icons/fa', () => ({
  FaUserCircle: () => <div>FaUserCircle</div>,
  FaRobot: () => <div>FaRobot</div>,
  FaPaperclip: () => <div>FaPaperclip</div>,
  FaPaperPlane: () => <div>FaPaperPlane</div>,
}));
jest.mock('react-icons/hi', () => ({
  HiX: () => <div>HiX</div>,
}));
jest.mock('flowbite-react', () => ({
  Button: ({ children }) => <button>{children}</button>,
  Textarea: ({ ...props }) => <textarea {...props} />,
  Popover: ({ children }) => <div>{children}</div>,
}));

// Mock fetch globally
global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve({}),
  })
);

describe('DashboardComp', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
    localStorage.setItem('token', 'fake-token');
    localStorage.setItem('status', 'Loggedin Successfully');
    
    Auth.fetchStatus.mockReturnValue('Loggedin Successfully');
    
    // Mock DashboardFetch functions
    DashboardFetch.uploadFile.mockResolvedValue({ detail: 'File uploaded successfully' });
    DashboardFetch.userPrompt.mockResolvedValue({
      response: 'I am a bot, I am here to help',
      detail: 'Test detail',
      image: [],
    });
  });

  test('renders without crashing', () => {
    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );
    expect(screen.getByPlaceholderText('Enter a prompt..')).toBeInTheDocument();
  });

  test('displays success toast on successful login', async () => {
    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );

    await waitFor(() => {
      expect(screen.getByText('Loggedin Successfully')).toBeInTheDocument();
    });
  });

  test('handles input change', () => {
    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );
    const input = screen.getByPlaceholderText('Enter a prompt..');
    fireEvent.change(input, { target: { value: 'Test input' } });
    expect(input.value).toBe('Test input');
  });

  test('handles form submission', async () => {
    // Set up mock implementation for userPrompt
    DashboardFetch.userPrompt.mockResolvedValue({
      response: 'Test response',
      detail: [], // Add any details you expect
      image: [], // Add any images you expect
    });

    // Render component
    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );

    // Simulate user input
    const textarea = screen.getByPlaceholderText('Enter a prompt..');
    fireEvent.change(textarea, { target: { value: 'Test input' } });

    // Simulate form submission
    const submitButton = screen.getByRole('button', { name: /FaPaperPlane/i });
    fireEvent.click(submitButton);

    // Check if userPrompt was called with correct arguments
    await waitFor(() => {
      expect(DashboardFetch.userPrompt).toHaveBeenCalledWith('Test input'); // Expect only one argument
    });
  });

  test('handles file upload with valid file', async () => {
    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );

    const file = new File(['test content'], 'test.pdf', { type: 'application/pdf' });
    const fileInput = screen.getByTestId('file-input');

    fireEvent.change(fileInput, { target: { files: [file] } });

    await waitFor(() => {
      expect(DashboardFetch.uploadFile).toHaveBeenCalled();
    });

    await waitFor(() => {
      expect(screen.getByText('File uploaded successfully')).toBeInTheDocument();
    });
  });

  test('closes toast message after timeout', async () => {
    jest.useFakeTimers();

    render(
      <BrowserRouter>
        <DashboardComp />
      </BrowserRouter>
    );

    await waitFor(() => {
      expect(screen.getByText('Loggedin Successfully')).toBeInTheDocument();
    });

    jest.advanceTimersByTime(4000);

    await waitFor(() => {
      expect(screen.queryByText('Loggedin Successfully')).not.toBeInTheDocument();
    });

    jest.useRealTimers();
  });
});
